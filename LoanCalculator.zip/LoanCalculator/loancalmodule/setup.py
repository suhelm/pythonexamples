from setuptools import setup
setup(
    name='loancalculator',
    version='1.0',
    description='loan emi calculator',
    author='suhel',
    author_email='suhelfirdus@gmail.com',
    url='abcdefgh.com',
    py_modules=['loancalculator'],
    )
